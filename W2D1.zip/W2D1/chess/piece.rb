#
# require_relative "piece_modules"
# require_relative 'board'

class Piece
  attr_reader :position
  attr_accessor :color

  def initialize(position, board)
    @position = position
    @color = nil
    @board = board
    give_color
  end

  private

  def give_color
    if @position[0] == 0 || @position[0] == 1
      @color = :blue
    else
      @color = :red
    end
  end

end
