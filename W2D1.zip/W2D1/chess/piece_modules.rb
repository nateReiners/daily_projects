require "byebug"

module SlidingPiece

  def diagonal_moves
    diag_moves = []

    pos_pos0 = self.position[0] - 1
    pos_pos1 = self.position[1] - 1

    #up and left
    until pos_pos0 < 0 || pos_pos1 < 0 || friendly_piece?([pos_pos0, pos_pos1])

      diag_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos0 -= 1
      pos_pos1 -= 1

    end

    pos_pos0 = self.position[0] - 1
    pos_pos1 = self.position[1] + 1

    #up and right
    until pos_pos0 < 0 || pos_pos1 > 7 || friendly_piece?([pos_pos0, pos_pos1])

      diag_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos0 -= 1
      pos_pos1 += 1
    end

    pos_pos0 = self.position[0] + 1
    pos_pos1 = self.position[1] + 1

    #down and right
    until pos_pos0 > 7 || pos_pos1 > 7 || friendly_piece?([pos_pos0, pos_pos1])

      diag_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos0 += 1
      pos_pos1 += 1
    end

    pos_pos0 = self.position[0] + 1
    pos_pos1 = self.position[1] - 1

    #down and left
    until pos_pos0 > 7 || pos_pos1 < 0 || friendly_piece?([pos_pos0, pos_pos1])

      diag_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos0 += 1
      pos_pos1 -= 1
    end

    return diag_moves
  end

  def friendly_piece?(pos)
    @board.grid[pos[0]][pos[1]].color == self.color
  end

  def enemy_piece?(pos)
    return false if @board.grid[pos[0]][pos[1]].is_a?(NullPiece)
    @board.grid[pos[0]][pos[1]].color != self.color
  end

  def straight_moves
    straight_moves = []

    pos_pos0 = self.position[0] - 1
    pos_pos1 = self.position[1]

    #up
    until pos_pos0 < 0 || friendly_piece?([pos_pos0, pos_pos1])

      straight_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos0 -= 1
    end

    pos_pos0 = self.position[0] + 1
    pos_pos1 = self.position[1]

    #down
    until pos_pos0 > 7 || friendly_piece?([pos_pos0, pos_pos1])

      straight_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos0 += 1
    end

    pos_pos0 = self.position[0]
    pos_pos1 = self.position[1] + 1

    #right
    until pos_pos1 > 7 || friendly_piece?([pos_pos0, pos_pos1])

      straight_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos1 += 1
    end

    pos_pos0 = self.position[0]
    pos_pos1 = self.position[1] - 1

    #left
    until pos_pos1 < 0 || friendly_piece?([pos_pos0, pos_pos1])

      straight_moves << [pos_pos0, pos_pos1]

      if enemy_piece?([pos_pos0, pos_pos1])
        break
      end

      pos_pos1 -= 1
    end

    return straight_moves
  end

  def moves
    diagonal_moves + straight_moves
  end

end


module SteppingPiece

  DIFF = {
    up: [-1, 0],
    down: [1, 0],
    left: [0, -1],
    upleft: [-1, -1],
    downleft: [1, -1],
    right: [0, 1],
    upright: [-1, 1],
    downright: [1, 1]
  }

  def moves
    stepmoves = []

    DIFF.each do |_, v|
      pos_pos0 = self.position[0] + v[0]
      pos_pos1 = self.position[1] + v[1]
      stepmoves << [pos_pos0, pos_pos1]
    end

    stepmoves.reject do |arr|
      arr.min < 0 || arr.max > 7 || friendly_piece?([pos_pos0, pos_pos1])
    end


  end

end
