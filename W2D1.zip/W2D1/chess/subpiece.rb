require_relative "piece"
require_relative "piece_modules"

class Rook < Piece
  include SlidingPiece

  def unique_moves
    straight_moves
  end

  def to_s
    if self.color == :blue
      "♖"
    else
      "♜"
    end
  end
end

class Knight < Piece
  def to_s
    if self.color == :blue
      "♘"
    else
      "♞"
    end
  end
end

class Bishop < Piece
  include SlidingPiece

  def unique_moves
    diagonal_moves
  end

  def to_s
    if self.color == :blue
      "♗"
    else
      "♝"
    end
  end

end

class Queen < Piece
  include SlidingPiece

  def unique_moves
    moves
  end

  def to_s
    if self.color == :blue
      "♕"
    else
      "♛"
    end
  end
end

class King < Piece
  def to_s
    if self.color == :blue
      "♔"
    else
      "♚"
    end
  end
end

class Pawn < Piece

  def unique_moves

  end

  def to_s
    if self.color == :blue
      "♙"
    else
      "♟"
    end
  end
end
