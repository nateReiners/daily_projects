require 'byebug'
require_relative "null_piece"
# require_relative "/Users/appacademy/Desktop/W2D1/chess/piece.rb"
require_relative "/Users/appacademy/Desktop/W2D1/chess/subpiece.rb"


class Board
  NULL_PIECE = NullPiece.instance
  attr_reader :grid

  def default_grid
    Array.new(8) { Array.new(8, nil) }
  end

  def initialize(grid = default_grid)
    @grid = grid
  end

  def move_piece(start_pos, end_pos)
    raise "Can't select empty spot" if @grid[start_pos[0]][start_pos[1]] == NULL_PIECE
    @grid[end_pos[0]][end_pos[1]] = @grid[start_pos[0]][start_pos[1]]
    @grid[start_pos[0]][start_pos[1]] = NULL_PIECE

    # make sure this raises exception for invalid input no piece at start
    #  or piece at end
  end

  def in_bounds?(pos)
    pos.all? do |el|
      el < @grid.length && el >= 0
    end
  end

  # private

  def populate
    rows_to_popuplate = [0, 1, @grid.length - 2, @grid.length - 1]
    back_row = [Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook]

    back_row.each_with_index do |class_name, i|
      [0, 7].each do |row_idx|
        @grid[row_idx][i] = class_name.new([row_idx, i], self)
      end
    end

    # debugger
    @grid.each_with_index do |row, row_idx|
      row.each_with_index do |el, i|
        if row_idx == 1 || row_idx == 6
          @grid[row_idx][i] = Pawn.new([row_idx, i], self)
        end
      end
    end

    @grid.each_with_index do |row, row_idx|
      row.each_with_index do |el, i|
        if row_idx.between?(2, 5)
          @grid[row_idx][i] = NULL_PIECE
        end
      end
    end

  end

end

board = Board.new
board.populate
p board.grid[1][3].moves
p board.grid[1][3].class
